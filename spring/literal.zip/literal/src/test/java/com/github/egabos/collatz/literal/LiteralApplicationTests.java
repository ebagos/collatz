package com.github.egabos.collatz.literal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiteralApplicationTests {

	@Test
	void contextLoads() {
	}

}
